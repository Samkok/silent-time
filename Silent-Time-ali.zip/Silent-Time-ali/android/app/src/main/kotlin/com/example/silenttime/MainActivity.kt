package com.example.silenttime

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
