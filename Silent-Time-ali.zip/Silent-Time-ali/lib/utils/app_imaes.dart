class AppImaes {
  static const String applogo = "assets/app_images/logoNew.jpg";
  // 'assets/app_images/appLogo.png';
  static const String splashImage = 'assets/app_images/splashImage.png';
  static const String noFigured = 'assets/app_images/noFigured.png';
  static const String infoImage = 'assets/svg/infoImage.svg';
  static const String arrowImage = 'assets/app_images/arrowpng.png';
  static const String trigerlogo = 'assets/app_images/triggerlogo.png';
  static const String arrowlightlogo = 'assets/app_images/trigerlighlogo.png';
  static const String actionlogo = 'assets/app_images/actionlogo.png';
  static const String ruleLogog = 'assets/app_images/ruleLogo.png';
  static const String locationLogog = 'assets/app_images/locationlogo.png';
  static const String mapImage = 'assets/app_images/mapImage.png';
  static const String notdisturbicon = 'assets/app_images/notdisturbicon.png';
  static const String silentIcon = 'assets/app_images/silentIcon.png';
  static const String speackerIcon = 'assets/app_images/speackerIcon.png';
  static const String vibrationIcon = 'assets/app_images/vibrationIcon.png';
  static const String volumnchangeIcon =
      'assets/app_images/volumnchangeIcon.png';
  static const String volumupdownIcon = 'assets/app_images/volumupdownIcon.png';
}
